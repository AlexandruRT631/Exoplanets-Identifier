module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/src/utils/input-utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fieldsNameDictionary",
    ()=>fieldsNameDictionary,
    "fieldsNameGroupsDictionary",
    ()=>fieldsNameGroupsDictionary,
    "getDefaultInputProps",
    ()=>getDefaultInputProps
]);
const fieldsNameGroupsDictionary = {
    "Orbital Period": [
        "period_d",
        "sigma_period_d",
        "asym_period_d",
        "is_limit_period_d"
    ],
    "Transit Duration": [
        "dur_hr",
        "sigma_dur_hr",
        "asym_dur_hr",
        "is_limit_dur_hr"
    ],
    "Transit Depth": [
        "depth_ppm",
        "sigma_depth_ppm",
        "asym_depth_ppm",
        "is_limit_depth_ppm"
    ],
    "Radius Ratio": [
        "ror",
        "sigma_ror",
        "asym_ror",
        "is_limit_ror"
    ],
    "Orbital / Transit Geometry": [
        "incl_deg",
        "a_over_r",
        "num_trans",
        "sma_au",
        "tranmid_bjd"
    ],
    "Planet Radius": [
        "prad_re",
        "sigma_prad_re",
        "asym_prad_re",
        "is_limit_prad_re"
    ],
    "Irradiation & Temperature": [
        "insol_ef",
        "teq_k",
        "sigma_teq_k",
        "asym_teq_k",
        "is_limit_teq_k"
    ],
    "Stellar Temperature": [
        "teff_k",
        "sigma_teff_k",
        "asym_teff_k",
        "is_limit_teff_k"
    ],
    "Stellar Gravity": [
        "logg_cgs",
        "sigma_logg_cgs",
        "asym_logg_cgs",
        "is_limit_logg_cgs"
    ],
    "Stellar Metallicity": [
        "met_dex",
        "sigma_met_dex",
        "asym_met_dex",
        "is_limit_met_dex"
    ],
    "Stellar Radius": [
        "rstar_rs",
        "sigma_rstar_rs",
        "asym_rstar_rs",
        "is_limit_rstar_rs"
    ],
    "Stellar Mass": [
        "mstar_ms",
        "sigma_mstar_ms",
        "asym_mstar_ms",
        "is_limit_mstar_ms"
    ],
    "Stellar Density": [
        "rho_cgs"
    ],
    "Detection & Multiplicity": [
        "snr",
        "multi_ct",
        "star_ct"
    ]
};
const fieldsNameDictionary = {
    period_d: "Orbital period (days)",
    sigma_period_d: "σ(Orbital period)",
    asym_period_d: "Asymmetry (Orbital period)",
    is_limit_period_d: "Is limit: Orbital period",
    dur_hr: "Transit duration (hours)",
    sigma_dur_hr: "σ(Transit duration)",
    asym_dur_hr: "Asymmetry (Transit duration)",
    is_limit_dur_hr: "Is limit: Transit duration",
    depth_ppm: "Transit depth (ppm)",
    sigma_depth_ppm: "σ(Transit depth)",
    asym_depth_ppm: "Asymmetry (Transit depth)",
    is_limit_depth_ppm: "Is limit: Transit depth",
    ror: "Planet–star radius ratio (Rp/R*)",
    sigma_ror: "σ(Rp/R*)",
    asym_ror: "Asymmetry (Rp/R*)",
    is_limit_ror: "Is limit: Rp/R*",
    incl_deg: "Orbital inclination (deg)",
    a_over_r: "Scaled semi-major axis (a/R*)",
    num_trans: "Number of observed transits",
    sma_au: "Semi-major axis (au)",
    tranmid_bjd: "Transit midpoint (BJD)",
    prad_re: "Planet radius (Earth radii)",
    sigma_prad_re: "σ(Planet radius)",
    asym_prad_re: "Asymmetry (Planet radius)",
    is_limit_prad_re: "Is limit: Planet radius",
    insol_ef: "Insolation flux (Earth flux)",
    teq_k: "Equilibrium temperature (K)",
    sigma_teq_k: "σ(Equilibrium temperature)",
    asym_teq_k: "Asymmetry (Equilibrium temperature)",
    is_limit_teq_k: "Is limit: Equilibrium temperature",
    teff_k: "Stellar effective temperature (K)",
    sigma_teff_k: "σ(Teff)",
    asym_teff_k: "Asymmetry (Teff)",
    is_limit_teff_k: "Is limit: Teff",
    logg_cgs: "Stellar surface gravity (log10 cm/s²)",
    sigma_logg_cgs: "σ(log g)",
    asym_logg_cgs: "Asymmetry (log g)",
    is_limit_logg_cgs: "Is limit: log g",
    met_dex: "Stellar metallicity [dex]",
    sigma_met_dex: "σ([M/H])",
    asym_met_dex: "Asymmetry ([M/H])",
    is_limit_met_dex: "Is limit: [M/H]",
    rstar_rs: "Stellar radius (solar radii)",
    sigma_rstar_rs: "σ(Stellar radius)",
    asym_rstar_rs: "Asymmetry (Stellar radius)",
    is_limit_rstar_rs: "Is limit: Stellar radius",
    mstar_ms: "Stellar mass (solar masses)",
    sigma_mstar_ms: "σ(Stellar mass)",
    asym_mstar_ms: "Asymmetry (Stellar mass)",
    is_limit_mstar_ms: "Is limit: Stellar mass",
    rho_cgs: "Stellar density (g/cm³)",
    snr: "Transit signal-to-noise ratio",
    multi_ct: "Number of planets in system",
    star_ct: "Number of stars in system"
};
const getDefaultInputProps = ()=>{
    return Object.keys(fieldsNameDictionary).reduce((acc, key)=>{
        acc[key] = undefined;
        return acc;
    }, {});
};
}),
"[project]/src/components/ButtonInput/ButtonInput.module.scss [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "button": "ButtonInput-module-scss-module__hovOSG__button",
});
}),
"[project]/src/components/ButtonInput/ButtonInput.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonInput$2f$ButtonInput$2e$module$2e$scss__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/ButtonInput/ButtonInput.module.scss [app-ssr] (css module)");
;
;
const ButtonInput = ({ action, title })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonInput$2f$ButtonInput$2e$module$2e$scss__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].button,
        onClick: action,
        children: title
    }, void 0, false, {
        fileName: "[project]/src/components/ButtonInput/ButtonInput.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ButtonInput;
}),
"[project]/src/components/ValueInput/ValueInput.module.scss [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "container": "ValueInput-module-scss-module__mmzmNG__container",
  "input": "ValueInput-module-scss-module__mmzmNG__input",
  "label": "ValueInput-module-scss-module__mmzmNG__label",
});
}),
"[project]/src/components/ValueInput/ValueInput.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueInput$2f$ValueInput$2e$module$2e$scss__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/ValueInput/ValueInput.module.scss [app-ssr] (css module)");
;
;
const ValueInput = ({ fieldName, value, setValue })=>{
    const onChange = (e)=>{
        const raw = e.target.value;
        setValue(raw === "" ? undefined : Number(raw));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueInput$2f$ValueInput$2e$module$2e$scss__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].container,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueInput$2f$ValueInput$2e$module$2e$scss__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].label,
                children: fieldName
            }, void 0, false, {
                fileName: "[project]/src/components/ValueInput/ValueInput.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueInput$2f$ValueInput$2e$module$2e$scss__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input,
                type: "number",
                value: value ?? "",
                onChange: onChange,
                onWheel: (e)=>e.currentTarget.blur(),
                onKeyDown: (e)=>{
                    if (e.key === "ArrowUp" || e.key === "ArrowDown") e.preventDefault();
                }
            }, void 0, false, {
                fileName: "[project]/src/components/ValueInput/ValueInput.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ValueInput/ValueInput.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ValueInput;
}),
"[project]/src/components/ValueGroup/ValueGroup.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$input$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/input-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueInput$2f$ValueInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ValueInput/ValueInput.tsx [app-ssr] (ecmascript)");
;
;
;
const ValueGroup = ({ groupTitle, keys, input, setInput })=>{
    const changeValue = (field, newValue)=>{
        setInput((prev)=>({
                ...prev,
                [field]: newValue
            }));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            display: "flex",
            flexWrap: "wrap",
            flexDirection: "row",
            margin: "12px"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                style: {
                    fontSize: "18px",
                    fontWeight: 600,
                    lineHeight: 1.2
                },
                children: groupTitle
            }, void 0, false, {
                fileName: "[project]/src/components/ValueGroup/ValueGroup.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    flexBasis: "100%",
                    height: 0
                }
            }, void 0, false, {
                fileName: "[project]/src/components/ValueGroup/ValueGroup.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            keys.map((fieldKey)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueInput$2f$ValueInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    fieldName: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$input$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fieldsNameDictionary"][fieldKey] ?? String(fieldKey),
                    value: input[fieldKey],
                    setValue: (e)=>changeValue(fieldKey, e)
                }, String(fieldKey), false, {
                    fileName: "[project]/src/components/ValueGroup/ValueGroup.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    flexBasis: "100%",
                    height: 0
                }
            }, void 0, false, {
                fileName: "[project]/src/components/ValueGroup/ValueGroup.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ValueGroup/ValueGroup.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ValueGroup;
}),
"[project]/src/components/PlanetInput/PlanetInput.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$input$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/input-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonInput$2f$ButtonInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ButtonInput/ButtonInput.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueGroup$2f$ValueGroup$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ValueGroup/ValueGroup.tsx [app-ssr] (ecmascript)");
;
;
;
;
const PlanetInput = ({ input, setInput, sendInput, sendCSV })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: "Input"
            }, void 0, false, {
                fileName: "[project]/src/components/PlanetInput/PlanetInput.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: "flex",
                    flexDirection: "column",
                    flexWrap: "wrap",
                    gap: 12,
                    alignItems: "flex-start"
                },
                children: [
                    Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$input$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fieldsNameGroupsDictionary"]).map(([groupTitle, keys])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ValueGroup$2f$ValueGroup$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            groupTitle: groupTitle,
                            keys: keys,
                            input: input,
                            setInput: setInput
                        }, groupTitle, false, {
                            fileName: "[project]/src/components/PlanetInput/PlanetInput.tsx",
                            lineNumber: 30,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: "flex",
                            flexDirection: "row"
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonInput$2f$ButtonInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                action: sendInput,
                                title: "Send Input"
                            }, void 0, false, {
                                fileName: "[project]/src/components/PlanetInput/PlanetInput.tsx",
                                lineNumber: 42,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ButtonInput$2f$ButtonInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                action: sendCSV,
                                title: "Send from CSV"
                            }, void 0, false, {
                                fileName: "[project]/src/components/PlanetInput/PlanetInput.tsx",
                                lineNumber: 43,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PlanetInput/PlanetInput.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PlanetInput/PlanetInput.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = PlanetInput;
}),
"[project]/src/app/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/components/ComponentWrapper/ComponentsWrapper'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PlanetInput$2f$PlanetInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PlanetInput/PlanetInput.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$input$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/input-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const Home = ()=>{
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$input$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDefaultInputProps"])());
    const sendInput = ()=>{
        console.log("SENDING INPUT");
        console.log(input);
    };
    const sendCSV = ()=>{
        console.log("SENDING CSV");
        console.log(JSON.stringify(input));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            padding: "12px",
            display: "flex",
            flexDirection: "column",
            gap: "16px"
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ComponentsWrapper, {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PlanetInput$2f$PlanetInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    input: input,
                    setInput: setInput,
                    sendInput: sendInput,
                    sendCSV: sendCSV
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 28,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PlanetInput$2f$PlanetInput$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    input: input,
                    setInput: setInput,
                    sendInput: sendInput,
                    sendCSV: sendCSV
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 34,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 27,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Home;
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        if ("TURBOPACK compile-time truthy", 1) {
            if ("TURBOPACK compile-time truthy", 1) {
                module.exports = __turbopack_context__.r("[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)");
            } else //TURBOPACK unreachable
            ;
        } else //TURBOPACK unreachable
        ;
    }
} //# sourceMappingURL=module.compiled.js.map
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].React; //# sourceMappingURL=react.js.map
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c9992da6._.js.map