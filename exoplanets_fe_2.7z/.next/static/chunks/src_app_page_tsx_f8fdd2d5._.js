(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_6376973d._.js",
  "static/chunks/src_components_32b9f3b0._.css"
],
    source: "dynamic"
});
